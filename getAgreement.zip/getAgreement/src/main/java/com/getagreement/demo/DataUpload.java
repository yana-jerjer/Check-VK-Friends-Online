package com.getagreement.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class DataUpload {

    protected Logger log;
    protected String whiteDomainList, blackDomainList, phoneList, cardList, agreement;
    protected String files =  "files/agreement.txt";

    @Autowired
    public DataUpload() {
        readFromFile (files);
        log = Logger.getLogger( Class.class.getName());
    }
    public Logger getLogger() {
        return log;
    }

    protected void readFromFile(String fileName) {
        try {
            InputStreamReader in = new InputStreamReader(new FileInputStream(fileName), "Cp1251");
            Scanner scan = new Scanner(in);
            String fileStr = "";
            while (scan.hasNextLine()) {
                fileStr += scan.nextLine() + ",";
            }
            scan.close();
            System.out.println("Загружен файл: " + fileName);
            fileStr = fileStr.replace(",$", "");
            if (fileName == "files/agreement.txt")
                agreement = fileStr;

        } catch (UnsupportedEncodingException ex) {
            System.out.println("UnsupportedEncodingException");
            log.log(Level.SEVERE, ex.toString() + " File: " + fileName, ex);
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFound_Exception");
            log.log(Level.SEVERE, e.toString() + " File: " + fileName, e);
        }
    }

}

